from __future__ import absolute_import
# Copyright (c) 2010-2015 openpyxl

from .formatting import ConditionalFormatting
from .rule import Rule
