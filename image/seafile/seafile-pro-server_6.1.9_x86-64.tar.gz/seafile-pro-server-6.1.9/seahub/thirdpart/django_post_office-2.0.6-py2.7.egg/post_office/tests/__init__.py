from .test_backends import BackendTest
from .test_commands import CommandTest
from .test_lockfile import LockTest
from .test_mail import MailTest
from .test_models import ModelTest
from .test_utils import UtilsTest
from .test_cache import CacheTest
from .test_views import AdminViewTest
