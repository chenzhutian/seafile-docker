"""Django Terms and Conditions Module"""
from __future__ import unicode_literals
