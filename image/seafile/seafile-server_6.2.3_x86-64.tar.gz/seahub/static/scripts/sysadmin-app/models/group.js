define([
    'underscore',
    'backbone',
    'common',
], function(_, Backbone, Common) {
    'use strict';

    var GroupModel = Backbone.Model.extend({});

    return GroupModel;
});
