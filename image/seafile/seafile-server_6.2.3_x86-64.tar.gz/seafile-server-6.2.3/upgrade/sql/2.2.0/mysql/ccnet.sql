ALTER TABLE EmailUser MODIFY passwd varchar(256);

